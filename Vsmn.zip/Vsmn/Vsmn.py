# Copyright (c) 2017-present, Facebook, Inc.
# All rights reserved.
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree. An additional grant
# of patent rights can be found in the PATENTS file in the same directory.

from parlai.core.agents import Agent
from parlai.core.dict import DictionaryAgent
from parlai.core.utils import round_sigfigs #, maintain_dialog_history
from parlai.core.thread_utils import SharedTable
#from .modules import Vsmn
import torch
from torch.autograd import Variable
import torch.autograd as autograd
from torch import optim
import torch.nn as nn
import time
from collections import deque
import numpy as np
import copy
import os
import random
import math
import pickle
import utils
import tensorflow as tf
from pickleshare import pickle
from keras.preprocessing.sequence import pad_sequences
from Vsmn_model import VSMN

dict_file = './data/vocab.pkl'
model_file = './data/model/best_validation'
embedding_file = './data/embedding.pkl'



def load_dict():
	f = open(dict_file, 'rb')
	dict = pickle.load(f)
	return dict
	
def load_embedding():
	f = open(embedding_file, 'rb')
	embedding = pickle.load(f)
	return embedding


	


def maintain_dialog_history(word_idx_map, history, observation, reply='',
							historyLength=15, useReplies="labels",
							useStartEndIndices=True,
							usePersonas=True):
	"""Keeps track of dialog history, up to a truncation length.
	Either includes replies from the labels, model, or not all using param 'replies'."""
	

	def parse(txt):	   
		max_l = 25
		txt = txt.replace('\\n', '').replace(".",' ').replace("n't"," not")
		line_id = []
		for w in txt.split():
			line_id.append(word_idx_map.get(w,0))
		line_id = line_id[:max_l]
		return line_id

	if 'dialog' not in history:
		history['dialog'] = []
		history['persona'] = []
		history['episode_done'] = False
		history['labels'] = []

	if history['episode_done']:
		history['dialog'] = []
		history['persona'] = []
		history['labels'] = []
		history['episode_done'] = False

	# we only keep the last one..that works well for IR model, so..
	#history['dialog'].clear()

	# if useReplies != 'none':
		# if len(history['labels']) > 0:
			# r = history['labels'][0]
			# history['dialog'].extend(parse(r))
		# else: #if useReplies == 'model':
			# if reply != '':
				# history['dialog'].extend(parse(reply))

	if 'text' in observation:
		txts = observation['text'].split('\n')
		for txt in txts:
			if usePersonas and 'persona:' in txt:
				txt1 = txt.split(':',1)[-1].strip()
				history['persona'].append(parse(txt1))
			else:
				utt = parse(txt)
				history['dialog'].append(utt)
				history['last_utterance'] = utt

	history['episode_done'] = observation['episode_done']
	if 'labels' in observation:
		history['labels'] = observation['labels']
	elif 'eval_labels' in observation:
		history['labels'] = observation['eval_labels']

	return history['dialog'], history['persona']


class VsmnAgent(Agent):
	"""Simple implementation of the memnn algorithm with 1 hop
	"""

	OPTIM_OPTS = {
		'adadelta': optim.Adadelta,
		'adagrad': optim.Adagrad,
		'adam': optim.Adam,
		'adamax': optim.Adamax,
		'asgd': optim.ASGD,
		'lbfgs': optim.LBFGS,
		'rmsprop': optim.RMSprop,
		'rprop': optim.Rprop,
		'sgd': optim.SGD,
	}

	@staticmethod
	def dictionary_class():
		return DictionaryAgent

	@staticmethod
	def add_cmdline_args(argparser):
		"""Add command-line arguments specifically for this agent."""
		VsmnAgent.dictionary_class().add_cmdline_args(argparser)
		agent = argparser.add_argument_group('Vsmn Arguments')
		agent.add_argument('-lr', '--learningrate', type=float, default=0.005,
						   help='learning rate')
		agent.add_argument('-opt', '--optimizer', default='sgd',
						   choices=VsmnAgent.OPTIM_OPTS.keys(),
						   help='Choose between pytorch optimizers. '
								'Any member of torch.optim is valid and will '
								'be used with default params except learning '
								'rate (as specified by -lr).')
		agent.add_argument('--take-next-utt', type='bool', default=False,
						   help='take next utt')
		agent.add_argument('--Vsmn-debug', type='bool', default=False,
						   help='print debug information')
		agent.add_argument('-hist', '--history-length', default=100, type=int,
						   help='Number of past tokens to remember. ')
		agent.add_argument('-histr', '--history-replies',
						   default='label', type=str,
						   choices=['none', 'model', 'label'],
						   help='Keep replies in the history, or not.')
		agent.add_argument('--interactive-mode',
						   default=False, type='bool',
						   choices=[True, False])

	def __init__(self, opt, shared=None):
		"""Set up model if shared params not set, otherwise no work to do."""
		super().__init__(opt, shared)
		opt = self.opt
		if opt.get('batchsize', 1) > 1:
			raise RuntimeError('Vsmn model does not support batchsize > 1, '
							   'try training with numthreads > 1 instead.')
		self.history = {}
		if shared:
			torch.set_num_threads(1)
			if 'threadindex' in shared:
				self.threadindex = shared['threadindex']
			else:
				self.threadindex = 1
		else:
			print("[ creating VsmnAgent ]")
			# this is not a shared instance of this class, so do full init
			self.threadindex = -1

			# self.model = Vsmn(opt, len(self.dict), self.dict)
			# if opt.get('model_file') and os.path.isfile(opt['model_file']):
				# self.load(opt['model_file'])
			# self.model.share_memory()

			print("=init done=")

		self.vsmn = VSMN('valid')
		self.vsmn.BuildModel()
		print ('load model~')
		self.sess = self.vsmn.LoadModel(model_file)
		print ('load dict~')
		self.word_idx_map = load_dict()



		
	def parse(self, txt):	   
		max_l = 25
		txt = txt.replace('\\n', '').replace(".",' ').replace("n't"," not")
		line_id = []
		for w in txt.split():
			line_id.append(self.word_idx_map.get(w,0))
		line_id = line_id[:max_l]
		return line_id




	def reset(self):
		"""Reset observation and episode_done."""
		self.observation = None
		self.episode_done = True
		self.cands_done = []
		self.history = {}
		# set up optimizer
		lr = self.opt['learningrate']
		optim_class = VsmnAgent.OPTIM_OPTS[self.opt['optimizer']]
		kwargs = {'lr': lr}
		self.optimizer = optim_class(self.model.parameters(), **kwargs)

	def share(self):
		"""Share internal states between parent and child instances."""
		shared = super().share()
		# shared['dict'] = self.dict
		# shared['model'] = self.model
		# if self.fixedX is not None:
			# shared['fixedX'] = self.fixedX
			# shared['fixedCands'] = self.fixedCands
			# shared['fixedCands_txt'] = self.fixedCands_txt
			# shared['fixedCands2'] = self.fixedCands2
			# shared['fixedCands_txt2'] = self.fixedCands_txt2
		return shared

	def observe(self, observation):
		self.episode_done = observation['episode_done']
		# shallow copy observation (deep copy can be expensive)
		obs = observation.copy()
		obs['query'],obs['mem'] = maintain_dialog_history(self.word_idx_map,
			self.history, obs,
			historyLength=self.opt['history_length'],
			useReplies=self.opt['history_replies'],
			useStartEndIndices=False)
		self.observation = obs
		return obs




	def predict(self, history_list, cands, cands_txt):
		max_num_utterance = self.vsmn.max_num_utterance
		max_sentence_len = self.vsmn.max_sentence_len
		if len(history_list)<1 or len(cands)<0 or len(cands_txt)<0:
			print ('error with the input observation!')
		history = history_list[0]
		cands_utt = cands[0]
		cands_utt_txt = cands_txt[0]
		history_batch = []
		for i in range(len(cands_utt)):
			history_batch.append(history.copy())
		history = history_batch.copy()
		
		#print ('history:\n',history)
		history, history_len = utils.multi_sequences_padding(history, max_sentence_len, max_num_utterance)
		history, history_len = np.array(history), np.array(history_len)
		cands_utt_len = np.array(utils.get_sequences_length(cands_utt, maxlen=max_sentence_len))
		cands_utt = np.array(pad_sequences(cands_utt, padding='post', maxlen=max_sentence_len))
		

		utterance_array = np.concatenate([history[:]], axis=0)	#add bigram cross matrix
		utterance_array_next = copy.deepcopy(utterance_array)
		utterance_array_next[:,:,:-1] = utterance_array[:,:,1:]

		response_array = np.concatenate([cands_utt[:]], axis=0)
		response_array_next = copy.deepcopy(response_array)
		response_array_next[:,:-1] = response_array[:,1:]
		feed_dict = {self.vsmn.utterance_ph: utterance_array,
					self.vsmn.utterance_next_ph: utterance_array_next,
					self.vsmn.all_utterance_len_ph: np.concatenate([history_len[:]], axis=0),
					self.vsmn.response_ph: response_array,
					self.vsmn.response_next_ph: response_array_next,
					self.vsmn.response_len: np.concatenate([cands_utt_len[:]], axis=0),
					}
		candidate_scores = self.sess.run(self.vsmn.y_pred, feed_dict=feed_dict)
		pred = list(candidate_scores[:, 1])
		sorted_pred = sorted(enumerate(pred), key=lambda y:y[1],reverse=True)	
		ind,preds = zip(*sorted_pred)
		ypred = cands_utt_txt[ind[0]] # match
		tc = []
		for i in range(min(100, len(ind))):
			tc.append(cands_utt_txt[ind[i]])
		ret = [{'text': ypred, 'text_candidates': tc }]
		return ret




	def batchify(self, observations):

		"""Convert a list of observations into input & target tensors."""
		def valid(obs):
			# check if this is an example our model should actually process
			return 'query' in obs and len(obs['query']) > 0
		try:
			# valid examples and their indices
			valid_inds, exs = zip(*[(i, ex) for i, ex in
									enumerate(observations) if valid(ex)])
		except ValueError:
			# zero examples to process in this batch, so zip failed to unpack
			return [],[]

		ys = None
		history_list = []
		cands = []
		cands_txt = []
		if ys is None:
			# only build candidates in eval mode.
			for o in observations:
				
				# concat the profile and dialog together
				if 'query' in o and 'mem' in o:
					exp_history = o['mem'] + o['query']
				if 'label_candidates' in o and o['label_candidates'] is not None:
					cs = []
					ct = []
					for c in o['label_candidates']:
						cs.append(self.parse(c))
						ct.append(c)
					history_list.append(exp_history)
					cands.append(cs)
					cands_txt.append(ct)
				else:
					cands.append(None)
					cands_txt.append(None)
		return history_list, cands, cands_txt
		
		

	def batch_act(self, observations):
		batchsize = len(observations)
		# initialize a table of replies with this agent's id
		batch_reply = [{'id': self.getID()} for _ in range(batchsize)]

		if batchsize == 0 or 'text' not in observations[0]:
			return [{ 'text': 'dunno' }]

		# convert the observations into batches of inputs and targets
		# valid_inds tells us the indices of all valid examples
		# e.g. for input [{}, {'text': 'hello'}, {}, {}], valid_inds is [1]
		# since the other three elements had no 'text' field
		history_list, cands, cands_txt = self.batchify(observations)
		#print (history_list)
		#print (cands)
		#print (cands_txt)
		batch_reply = self.predict(history_list, cands, cands_txt)
		#self.add_to_ys_cache(ys)
		return batch_reply

	def act(self):
		# call batch_act with this batch of one
		return self.batch_act([self.observation])[0]



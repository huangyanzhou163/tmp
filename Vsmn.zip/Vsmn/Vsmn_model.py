import tensorflow as tf
from pickleshare import pickle
import utils
from keras.preprocessing.sequence import pad_sequences
import numpy as np
import os
import random
import copy
from sklearn import preprocessing 
random.seed(12345)

embedding_file = r"./data/embedding.npy"
valid_data_file = r"./data/valid_data.pkl"
model_file = './data/model/best_validation'




class VSMN():


	def __init__(self,mode='train'):
		self.max_num_utterance = 15
		self.negative_samples = 19
		self.max_sentence_len = 21
		self.word_embedding_size = 300
		self.num_filters = 100
		self.rnn_units = 300
		self.embeddings = np.load(embedding_file)
		self.embeddings = preprocessing.normalize(self.embeddings, norm='l2')
		self.total_words = len(self.embeddings)
		#self.total_words = 20220  #试试rewised 和 orignal一起训练
		self.batch_size = 20
		if mode == 'train' or mode == 'predict':
			f = open(valid_data_file, 'rb')
			self.valid_history, self.valid_true_utt, self.valid_labels = pickle.load(f)
			f.close()

	def LoadModel(self,model_file):
		saver = tf.train.Saver()
		sess = tf.Session()
		saver.restore(sess,model_file)
		return sess



	def BuildModel(self):
		self.utterance_ph = tf.placeholder(tf.int32, shape=(None, self.max_num_utterance, self.max_sentence_len))
		self.utterance_next_ph = tf.placeholder(tf.int32, shape=(None, self.max_num_utterance, self.max_sentence_len)) #
		self.response_ph = tf.placeholder(tf.int32, shape=(None, self.max_sentence_len))
		self.response_next_ph = tf.placeholder(tf.int32, shape=(None, self.max_sentence_len)) #
		
		self.y_true = tf.placeholder(tf.int32, shape=(None,))
		self.embedding_ph = tf.placeholder(tf.float32, shape=(self.total_words, self.word_embedding_size))
		self.response_len = tf.placeholder(tf.int32, shape=(None,))
		self.all_utterance_len_ph = tf.placeholder(tf.int32, shape=(None, self.max_num_utterance))
		word_embeddings = tf.get_variable('word_embeddings_v', shape=(self.total_words,self.
																	  word_embedding_size), dtype=tf.float32, trainable=False)
		self.embedding_init = word_embeddings.assign(self.embedding_ph)
		all_utterance_embeddings = tf.nn.embedding_lookup(word_embeddings, self.utterance_ph)
		all_utterance_embeddings_next = tf.nn.embedding_lookup(word_embeddings, self.utterance_next_ph)	#
		all_utterance_embeddings_bigram = tf.add(all_utterance_embeddings,all_utterance_embeddings_next)/2	#
		
		response_embeddings = tf.nn.embedding_lookup(word_embeddings, self.response_ph)
		response_embeddings_next = tf.nn.embedding_lookup(word_embeddings, self.response_next_ph) #
		response_embeddings_bigram = tf.add(response_embeddings,response_embeddings_next)/2 #
		sentence_GRU = tf.nn.rnn_cell.GRUCell(self.rnn_units, kernel_initializer=tf.orthogonal_initializer())
		sentence_GRU_fw = tf.nn.rnn_cell.GRUCell(self.rnn_units/2, kernel_initializer=tf.orthogonal_initializer())
		sentence_GRU_bw = tf.nn.rnn_cell.GRUCell(self.rnn_units/2, kernel_initializer=tf.orthogonal_initializer())
		all_utterance_embeddings = tf.unstack(all_utterance_embeddings, num=self.max_num_utterance, axis=1)
		all_utterance_embeddings_bigram = tf.unstack(all_utterance_embeddings_bigram, num=self.max_num_utterance, axis=1)	#
		all_utterance_len = tf.unstack(self.all_utterance_len_ph, num=self.max_num_utterance, axis=1)
		A_matrix = tf.get_variable('A_matrix_v', shape=(self.rnn_units, self.rnn_units), initializer=tf.contrib.layers.xavier_initializer(), dtype=tf.float32)
		final_GRU = tf.nn.rnn_cell.GRUCell(self.rnn_units, kernel_initializer=tf.orthogonal_initializer())
		reuse = None
		reuse1 = None
		
		response_GRU_embeddings, _ = tf.nn.dynamic_rnn(sentence_GRU, response_embeddings, sequence_length=self.response_len, dtype=tf.float32,
													   scope='sentence_GRU')
		bidirectional_rnn_response_embeddings, _ = tf.nn.bidirectional_dynamic_rnn(sentence_GRU_fw, sentence_GRU_bw, response_embeddings, sequence_length=self.response_len, dtype=tf.float32,
															scope='bidirectional_rnn_response_embeddings')
															
		new_response_embeddings = tf.concat([bidirectional_rnn_response_embeddings[0],bidirectional_rnn_response_embeddings[1]],axis=2)
		self.response_embedding_save = response_GRU_embeddings
		response_embeddings_transpose = tf.transpose(response_embeddings, perm=[0, 2, 1])
		new_response_embeddings = tf.transpose(new_response_embeddings, perm=[0, 2, 1])
		response_embeddings_bigram = tf.transpose(response_embeddings_bigram, perm=[0, 2, 1])
		

		zero_vec = tf.reduce_sum(tf.zeros_like(response_embeddings, dtype = tf.float32), 1, keepdims=True)
		response_embeddings_concat = tf.concat([response_embeddings,zero_vec],1)
		response_embeddings_concat1 = tf.concat([zero_vec,response_embeddings,zero_vec],1)

		r_v1 = tf.layers.conv1d(response_embeddings, self.num_filters, kernel_size=1, kernel_initializer=tf.contrib.keras.initializers.he_normal(),
				activation=tf.nn.relu, reuse=reuse1, name='conv1')
		print ('r_v1 shape:',r_v1.get_shape())
		r_v1 = tf.reduce_max(r_v1, 1, keepdims=False)
		print ('r_v1 shape:',r_v1.get_shape())
		
		r_v2 = tf.layers.conv1d(response_embeddings_concat, self.num_filters, kernel_size=2, kernel_initializer=tf.contrib.keras.initializers.he_normal(),
						activation=tf.nn.relu, reuse=reuse1, name='conv2');
		r_v2 = tf.reduce_max(r_v2, 1, keepdims=False)

		r_v3 = tf.layers.conv1d(response_embeddings_concat1, self.num_filters, kernel_size=3, kernel_initializer=tf.contrib.keras.initializers.he_normal(),
						activation=tf.nn.relu, reuse=reuse1, name='conv3');
						
		r_v3 = tf.reduce_max(r_v3, 1, keepdims=False)
		
		r_v_concat = tf.concat([r_v1,r_v2,r_v3],1)
		
		response_embeddings_max = tf.reduce_max(response_embeddings, 1, keepdims=False)
		response_embeddings_sum = tf.reduce_sum(response_embeddings, 1, keepdims=False)
		response_embeddings_max_mode = tf.sqrt(tf.reduce_sum(tf.square(response_embeddings_max+0.0000001), 1, keepdims=True))
		response_embeddings_sum_mode = tf.sqrt(tf.reduce_sum(tf.square(response_embeddings_sum+0.0000001), 1, keepdims=True))
		print ('response_embeddings_max shape:',response_embeddings_max.get_shape())
		reuse1 = True
		response_GRU_embeddings = tf.transpose(response_GRU_embeddings, perm=[0, 2, 1])
		matching_vectors = []
		max_vectors = []
		sum_vectors = []
		for utterance_embeddings, utterance_len, utterance_embeddings_bigram in zip(all_utterance_embeddings, all_utterance_len, all_utterance_embeddings_bigram):
			#print (utterance_embeddings.get_shape())
			bidirectional_rnn_embeddings, _ = tf.nn.bidirectional_dynamic_rnn(sentence_GRU_fw, sentence_GRU_bw, utterance_embeddings, sequence_length=utterance_len, dtype=tf.float32,
															scope='bidirectional_rnn_embeddings')
			new_utterance_embeddings = tf.concat([bidirectional_rnn_embeddings[0],bidirectional_rnn_embeddings[1]],axis=2)
			
			utterance_embeddings_max = tf.reduce_max(utterance_embeddings, 1, keepdims=False)
			utterance_embeddings_sum = tf.reduce_sum(utterance_embeddings, 1, keepdims=False)
			utterance_embeddings_max_mode = tf.sqrt(tf.reduce_sum(tf.square(utterance_embeddings_max+0.0000001), 1, keepdims=True))
			utterance_embeddings_sum_mode = tf.sqrt(tf.reduce_sum(tf.square(utterance_embeddings_sum+0.0000001), 1, keepdims=True))
			embeddings_max_cos = tf.reduce_sum(tf.multiply(utterance_embeddings_max,response_embeddings_max), 1, keepdims=True)/(utterance_embeddings_max_mode*response_embeddings_max_mode)
			embeddings_sum_cos = tf.reduce_sum(tf.multiply(utterance_embeddings_sum,response_embeddings_sum), 1, keepdims=True)/(utterance_embeddings_sum_mode*response_embeddings_sum_mode)
			
			print ('embeddings_max_cos shape:',embeddings_max_cos.get_shape())
			
			utterance_embeddings_concat = tf.concat([utterance_embeddings,zero_vec],1)
			utterance_embeddings_concat1 = tf.concat([zero_vec,utterance_embeddings,zero_vec],1)
			
			u_v1 = tf.layers.conv1d(utterance_embeddings, self.num_filters,kernel_size=1, kernel_initializer=tf.contrib.keras.initializers.he_normal(),
					activation=tf.nn.relu, reuse=reuse1, name='conv1')
					
			# print ('u_v1 shape:',u_v1.get_shape())
			u_v1 = tf.reduce_max(u_v1, 1, keepdims=False)
			# print ('u_v1 reduce_max shape:',u_v1.get_shape())
			
			u_v2 = tf.layers.conv1d(utterance_embeddings_concat, self.num_filters, kernel_size=2, kernel_initializer=tf.contrib.keras.initializers.he_normal(),
							activation=tf.nn.relu, reuse=reuse1, name='conv2');
			u_v2 = tf.reduce_max(u_v2, 1, keepdims=False)

			u_v3 = tf.layers.conv1d(utterance_embeddings_concat1, self.num_filters, kernel_size=3, kernel_initializer=tf.contrib.keras.initializers.he_normal(),
							activation=tf.nn.relu, reuse=reuse1, name='conv3');
			u_v3 = tf.reduce_max(u_v3, 1, keepdims=False)
			
			u_v_concat = tf.concat([u_v1,u_v2,u_v3], 1)
			
			matrix0 = tf.matmul(new_utterance_embeddings, new_response_embeddings)
			
			matrix1 = tf.matmul(utterance_embeddings, response_embeddings_transpose)
			
			#add bigram cross matrix
			matrix3 = tf.matmul(utterance_embeddings_bigram, response_embeddings_bigram)
			matrix4 = tf.matmul(utterance_embeddings, response_embeddings_bigram)
			matrix5 = tf.matmul(utterance_embeddings_bigram, response_embeddings_transpose)
			
			matrix6 = tf.matmul(new_utterance_embeddings, response_embeddings_transpose)
			matrix7 = tf.matmul(new_utterance_embeddings, response_embeddings_bigram)
			matrix8 = tf.matmul(utterance_embeddings, new_response_embeddings)
			matrix9 = tf.matmul(utterance_embeddings_bigram, new_response_embeddings)
			
			utterance_GRU_embeddings, _ = tf.nn.dynamic_rnn(sentence_GRU, utterance_embeddings, sequence_length=utterance_len, dtype=tf.float32,
															scope='sentence_GRU')
			# print ('u_v1 utterance_GRU_embeddings shape:',utterance_GRU_embeddings.get_shape())
			matrix2 = tf.einsum('aij,jk->aik', utterance_GRU_embeddings, A_matrix)  # TODO:check this
			# print ('matrix2 shape:',matrix2.get_shape())
			matrix2 = tf.matmul(matrix2, response_GRU_embeddings)
			# print ('matrix2 shape:',matrix2.get_shape())

			
			matrix = tf.stack([matrix0, matrix1, matrix3, matrix4, matrix5, matrix6, matrix7, matrix8, matrix9, matrix2], axis=3, name='matrix_stack')
			#matrix = tf.expand_dims(matrix2,-1)
			conv_layer = tf.layers.conv2d(matrix, filters=16, kernel_size=(3, 3), padding='VALID',
										  kernel_initializer=tf.contrib.keras.initializers.he_normal(),
										  activation=tf.nn.relu, reuse=reuse, name='conv')  # TODO: check other params
			pooling_layer = tf.layers.max_pooling2d(conv_layer, (3, 3), strides=(3, 3),
													padding='VALID', name='max_pooling')  # TODO: check other params
			matching_vector = tf.layers.dense(tf.contrib.layers.flatten(pooling_layer), 50,
											  kernel_initializer=tf.contrib.layers.xavier_initializer(),
											  activation=tf.tanh, reuse=reuse, name='matching_v')  # TODO: check wthether this is correct
			u_r_v_concat = tf.concat([u_v_concat,r_v_concat], 1)
			
			matching_vector1 = tf.layers.dense(u_r_v_concat, 50,
								  kernel_initializer=tf.contrib.layers.xavier_initializer(),
								  activation=tf.tanh, reuse=reuse, name='matching_v1')  # TODO: check wthether this is correct
								  
			matching_vector_cancat =  tf.concat([matching_vector, matching_vector1, embeddings_max_cos, embeddings_sum_cos],1)
			print ('matching_vector_cancat shape:',matching_vector_cancat.get_shape())
			
			if not reuse:
				reuse = True
			matching_vectors.append(matching_vector_cancat)
		_, last_hidden = tf.nn.dynamic_rnn(final_GRU, tf.stack(matching_vectors, axis=0, name='matching_stack'), dtype=tf.float32,
										   time_major=True, scope='final_GRU')  # TODO: check time_major
		logits = tf.layers.dense(last_hidden, 2, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='final_v')
		print (logits.get_shape())
		self.y_pred = tf.nn.softmax(logits)
		print (self.y_pred.get_shape())
		self.total_loss = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(labels=self.y_true, logits=logits))
		tf.summary.scalar('loss', self.total_loss)
		optimizer = tf.train.AdamOptimizer(learning_rate=0.001)
		# optimizer = tf.keras.optimizers.Nadam(lr=0.001)
		self.train_op = optimizer.minimize(self.total_loss)



	def Predict(self,sess):
		batch_size = 20
		#with open(valid_data_file, 'rb') as f:
			#history, true_utt,labels = pickle.load(f)
		self.all_candidate_scores = []
		history = copy.deepcopy(self.valid_history)
		true_utt = copy.deepcopy(self.valid_true_utt)
		labels = copy.deepcopy(self.valid_labels)
		history, history_len = utils.multi_sequences_padding(history, self.max_sentence_len, self.max_num_utterance)
		history, history_len = np.array(history), np.array(history_len)
		true_utt_len = np.array(utils.get_sequences_length(true_utt, maxlen=self.max_sentence_len))
		true_utt = np.array(pad_sequences(true_utt, padding='post', maxlen=self.max_sentence_len))
		

		low = 0
		while True:
			utterance_array = np.concatenate([history[low:low + batch_size]], axis=0)	#add bigram cross matrix
			utterance_array_next = copy.deepcopy(utterance_array)
			utterance_array_next[:,:,:-1] = utterance_array[:,:,1:]

			response_array = np.concatenate([true_utt[low:low + batch_size]], axis=0)
			response_array_next = copy.deepcopy(response_array)
			response_array_next[:,:-1] = response_array[:,1:]
			feed_dict = {self.utterance_ph: utterance_array,
						self.utterance_next_ph: utterance_array_next,
						self.all_utterance_len_ph: np.concatenate([history_len[low:low + batch_size]], axis=0),
						self.response_ph: response_array,
						self.response_next_ph: response_array_next,
						self.response_len: np.concatenate([true_utt_len[low:low + batch_size]], axis=0),
						}
			candidate_scores = sess.run(self.y_pred, feed_dict=feed_dict)
			pred = list(candidate_scores[:, 1])		
			sorted_pred = sorted(enumerate(pred), key=lambda y:y[1],reverse=True)	
			ind,preds = zip(*sorted_pred)
			low = low + batch_size
			break
			if low >= history.shape[0]:
				break
		# all_candidate_scores = np.concatenate(self.all_candidate_scores, axis=0)
		# acc, hit1_rate, hit5_rate, hit10_rate = ComputeR20_1(all_candidate_scores,labels)
		return 0


if __name__ == "__main__":
	mode = 'predict'
	vsmn = VSMN(mode)
	vsmn.BuildModel()
	if mode == 'predict':
		sess = vsmn.LoadModel(model_file)
		vsmn.Predict(sess)
	else:
		vsmn.TrainModel()
	
	#sess = scn.LoadModel()
	#scn.Evaluate(sess)
	#results = scn.BuildIndex(sess)
	#print(len(results))

	#scn.TrainModel()
